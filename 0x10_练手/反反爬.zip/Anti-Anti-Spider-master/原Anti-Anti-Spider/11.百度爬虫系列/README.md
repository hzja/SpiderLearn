

详解：http://blog.csdn.net/xunalove/article/category/7252282
