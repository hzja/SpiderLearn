在程序调用phantomjs的时候，可能因phantomjs死锁导致的进程僵死。。
测试进程下设置超时时间。
