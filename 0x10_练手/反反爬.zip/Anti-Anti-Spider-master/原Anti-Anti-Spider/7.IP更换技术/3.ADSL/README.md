adsl

详细部署方式在:

https://www.urlteam.org/2016/08/%E7%88%AC%E8%99%AB%E7%A0%B4%E8%A7%A3ip%E9%99%90%E5%88%B6-adsl%E5%8A%A8%E6%80%81ip%E6%9C%8D%E5%8A%A1%E5%99%A8-%E9%83%A8%E7%BD%B2%E5%B0%8F%E7%BB%93/

更换ip的样例代码在
chage.py

环境需求需要直到宽带的账号密码,



