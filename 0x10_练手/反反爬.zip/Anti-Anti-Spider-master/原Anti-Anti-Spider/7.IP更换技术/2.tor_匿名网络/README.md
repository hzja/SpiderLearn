2016-12-8 完成 tor采集的测试.

完成了tor的测试代码
tor环境需要翻墙进行安装以及运行
具体过程请看博客

https://www.urlteam.org/2016/12/%E5%9F%BA%E4%BA%8Etor%E5%8C%BF%E5%90%8D%E7%BD%91%E7%BB%9C%E7%9A%84%E5%A4%9Aip%E7%88%AC%E8%99%AB/

主要样例代码请看
requesocks.py

