
环境需求  pt5 openpyxl codecs

from PyQt5 import QtCore, QtGui, QtWidgets
import openpyxl
import codecs


在linux ubuntu 16.04 上测试通过.
代码功能,制定搜索项,比如美食,.将百度地图中制定城市的相关数据名采集出来,此项目作为可视化采集器的模板代码

截图在本目录下

数据可导出为excel格式

