在模拟浏览器方面有selenium 以及phantomjs 还有一个python ghost。
之前使用phantomjs破解过极验验证码，如今测试使用ghost来完成破解

官方手册在：http://ghost-py.readthedocs.io/en/latest/#installation
