然后在当前目录下命令行运行：就会返回整个网页的源码，然后爬虫你懂得的小解析一下就可以抽取出xici代理的免费ip了。
phantomjs request.js http://www.xicidaili.com/

参看xicidaili.txt 即该页面的源代码,生成该网站是用 > 命令
phantomjs request.js http://www.xicidaili.com/ > xicidaili.txt

本部分均有涉及到请求头字段的伪造。

包含x-forword部分
