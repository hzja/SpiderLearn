<html><head>
<meta http-equiv="Content-type" content="text/html; charset=iso-8859-1">
<title>Test 1</title>
</head>
<body marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" background="wall.jpg" bgcolor="black" text="white">
<br><br>
<table border="0" width="650" align="CENTER" cellspacing="0">
<tbody><tr>
<td width="16%" valign="CENTER" align="center"><a href="./../index.shtml"><img src="main.gif" border="0"></a></td>
<td width="16%" valign="CENTER" align="center"><a href="./../envv/environmentchk.pl"><img src="env.gif" border="0"></a></td>
<td width="16%" valign="CENTER" align="CENTER"><img src="test1.gif" border="0"></td>
<td width="16%" valign="CENTER" align="center"><a href="./../test2/"><img src="test2.gif" border="0"></a></td>
<td width="16%" valign="CENTER" align="center"><a href="./../ssi/"><img src="SSI.gif" border="0"></a></td>
<td width="16%" valign="CENTER" align="center"><a href="./../Java/"><img src="java.gif" border="0"></a></td>


</tr>
</tbody></table>


<br>


<center>
<br>Another test<br>
</center>



<!--¸¡ººÅê¹Æ¥Õ¥©¡¼¥à-->

<center>
<br>

<table>

<tbody><tr><td colspan="2" bgcolor="#008080">
<font size="4">Your Host Information</font>
</td></tr>

<tr><td nowrap="">REMOTE_HOST</td>
<td>47.90.81.122</td>
</tr>
<tr><td nowrap="">REMOTE_ADDR</td>
<td>47.90.81.122</td>
</tr>

 <tr><td nowrap="">USER_AGENT</td>
<td>Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36</td>
</tr>


 <tr><td>HTTP_REFERER</td>
<td><font color="gray">(none)</font></td>
</tr>



<tr><td colspan="2" bgcolor="#008080">
<font size="4">HTTP Connection Information</font>
</td></tr>

<tr><td>HTTP_FORWARDED</td>
<td><font color="green">(none)</font></td>
</tr>

<tr><td>HTTP_X_FORWARDED_FOR</td>
<td><font color="red"><b>123.123.123.123</b></font></td>
</tr>

<tr><td>HTTP_VIA</td>
<td><font color="gray">(none)</font></td>
</tr>

<tr><td>HTTP_CONNECTION</td>
<td>keep-alive</td>
</tr>

<tr><td>HTTP_SP_HOST</td>
<td><font color="gray">(none)</font></td>
</tr>

<tr><td>HTTP_CACHE_INFO</td>
<td><font color="gray">(none)</font></td>
</tr>

<tr><td>HTTP_CLIENT_IP</td>
<td><font color="gray">(none)</font></td>
</tr>

<tr><td>HTTP_CACHE_CONTROL</td><td><u>max-age=0</u></td></tr>
 <tr><td>HTTP_COOKIE</td><td><u></u></td></tr>


<tr><td colspan="2" bgcolor="#008080">
<font size="4">Your IP or Proxy Server Name</font>
</td>

</tr><tr><td colspan="2">
<b><font size="4" color="yellow">123.123.123.123</font></b><br>

<font size="+1">1</font>
<font size="+1">2</font><br>
Ï³¤ì¶ú¤Ç¤¹¡£<font size="+1">1</font> ²Õ½ê¤«¤éÏ³¤ì¤Æ¤¤¤Þ¤¹¡£<br>
<font size="+2">C</font><font size="+2">-</font><br><br>

<br>
<br>
<u> HTTP_COOKIE=
 </u><br><br>
</td></tr>
</tbody></table>
</center>



<br><br>
<center>
<br>
<center><font size="2" color="#ffff80">Total visitors:</font><br><table>
<tbody><tr>
  <td></td>
  <td>
    <table border="1" bordercolor="#33cc99">
    <tbody><tr>
      <td><img src="t1dayx.cgi?gif"></td>
    </tr>
    </tbody></table>
  </td>
  <td></td>
</tr>
</tbody></table><br>
<table border="0" <tr=""><tbody><tr><td valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size="2" color="#ffff80">Today:&nbsp;</font></td>
<td valign="bottom"><img border="0" src="left.gif" width="6" height="23"><img src="t1dayx.cgi?today"><img border="0" src="right.gif" width="6" height="23">&nbsp;&nbsp;</td>
<td valign="top"><img border="0" src="left.gif" width="6" height="23"><img src="t1dayx.cgi?yes"><img border="0" src="right.gif" width="6" height="23"></td>
<td valign="top"><font size="2" color="#ffff80">: Yesterday</font></td>
</tr>
</tbody></table>
</center>

<br>

<!-- END DO NOT MODIFY -->

</center>




</body></html>

