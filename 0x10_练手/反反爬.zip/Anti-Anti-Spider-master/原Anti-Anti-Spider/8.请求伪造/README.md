最基础的反反爬虫莫过于伪造请求头。
现在分别用
urllib
uellib2
scrapy
requests
phantomjs
来分别实现对head的伪造。
提供两个函数，
分别是直接写于代码中的header
还有通过读取一个数M大小的随机user-agent来实现随机化的用户信息。

