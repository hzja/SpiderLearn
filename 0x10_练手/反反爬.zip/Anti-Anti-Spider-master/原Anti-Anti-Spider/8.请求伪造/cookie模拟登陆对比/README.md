
因公司教学需要完成的一个简单对比

通过requests模块。
发起普通请求与携带cookie的请求与返回的数据如下：
requests_test.py && requests+cookie.py
requests_test.html && requests+cookie.html
可以从源代码中看出携带cookie便自带登陆功能。

通过phantomjs-无头浏览器。
