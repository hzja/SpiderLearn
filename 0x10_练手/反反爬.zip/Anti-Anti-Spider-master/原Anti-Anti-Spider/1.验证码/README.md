
本目录记录关于验证码识别的探索和代码

主要项目：

1：基于TensorFlow进行验证码的自动生成和训练识别
成功率破 95%以上
台式i5机 训练耗时 2天
目录 tensorrflow_cnn

2：亚马逊验证码破解
目录AmazonCaptcha
成功率 70%

3：图片相似性比较识别-knn算法
knn_num_captcha
识别率：低。

4：使用python包--pytesseract
目录 pytesseract
识别率：低
