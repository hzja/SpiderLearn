
本项目由URLteam维护
项目使用说明文档在：
https://www.urlteam.org/category/web_crawlers/urlspider/

文件结构分为两部分

model   模板文件 -- 请使用本模板进行修改

example  样例文件 -- 可以参考我对该模板修改后进行的爬虫代码，一般需要导入数据库后才可以运行

详情请致电 a83533774@gmail.com
或者在说明文档下留言
