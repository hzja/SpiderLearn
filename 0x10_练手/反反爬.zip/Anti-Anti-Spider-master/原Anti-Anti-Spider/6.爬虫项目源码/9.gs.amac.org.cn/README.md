完成对于gs.amac.org.cn所有信息url的抓取，抓取的信息放在urllist里面。没有进行保存也没有进行详细信息的抓取，详细信息有太多项目，对我来说工作量太大
Completion of all the information for the gs.amac.org.cn crawl, crawl information on the inside of the urllist. There is no save the details of the crawl, there are too many details of the project, for me too much work
