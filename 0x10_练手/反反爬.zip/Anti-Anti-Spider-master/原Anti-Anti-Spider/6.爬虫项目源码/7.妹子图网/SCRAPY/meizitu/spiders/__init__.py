#coding:utf-8
# This package will contain the spiders of your Scrapy project
#
# Please refer to the documentation for information on how to create and manage
# your spiders.
import scrapy
#from scrapy import log
#开启注释,在部分机器上会报错，因为环境没有搭建好
#log.msg("This is a warning", level=log.WARNING)
#scrapy.log.start()
