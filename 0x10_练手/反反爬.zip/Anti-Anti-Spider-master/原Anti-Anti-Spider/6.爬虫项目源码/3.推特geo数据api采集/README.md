增加正在运行中的twitter采集代码

采用官方接口采集GEO带有位置信息的推文数据
接口的文档在:
https://dev.twitter.com/rest/reference/get/geo/search

需要申请开发者帐号,将应用信息填写到config.py中

我分享部分twitter的采集结果,目标是台北101大厦的附近地区
请看数据库sql文件

