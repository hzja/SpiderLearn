使用scrapy并且加如redis来测试代理功能。
在middlewares中设置redis读取ip：port加入代理去请求
http://www.j4.com.tw/james/remoip.php
如果成功可以返回代理之后的ip
