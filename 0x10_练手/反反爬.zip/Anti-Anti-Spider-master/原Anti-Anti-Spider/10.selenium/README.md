
ubuntu 16.04 下安装selenium + phantomjs 环境,

安装mac下chrome内核
运行 bash down_mac_chrome.sh
即会再同目录下产生mac64位的文件，同时已经移动到系统目录中，程序可以使用了。
