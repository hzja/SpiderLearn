使用以wrbkit为内核，以python为语言进行模拟可视化打开浏览器的过程。


1:测试环境

在终端运行：

sudo python open_url.py https://www.baidu.com	

